Reference : Lewandowski D, Kurowicka D and Joe H (2009).
Generating random correlation matrices based on vines and extended
 onion method. J. Multivariate Analysis, v 100, pp 1989-2001.

R code (.r files); see Makefile for tests
C code (.c files); see Makefile for compilations and tests

Generate random correlation matrices R, density propto [det(R)]^{eta-1}
ronion.r, function rcoronion(): Onion method 
rcvine.r, function rcorcvine(): C-vine method 
onion.c, function rcoronion(): Onion method 
cvine.c, function rcorcvine() : C-vine method

